
import pandas as pd
df = pd.read_csv("dataset.csv")
df = df.drop_duplicates()
df["Salary"] = df["Salary"].fillna(df["Salary"].median())
df["Department"] = df["Department"].fillna(df["Department"].mode()[0])
df.to_csv("cleaned_dataset.csv", index=False)
print("Cleaning completed")
